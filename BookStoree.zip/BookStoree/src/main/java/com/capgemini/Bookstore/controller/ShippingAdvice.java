package com.capgemini.Bookstore.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.capgemini.Bookstore.exception.ErrorInfo;
import com.capgemini.Bookstore.exception.ShippingException;

@RestControllerAdvice
public class ShippingAdvice {
	
		@ExceptionHandler(value = {ShippingException.class})
		@ResponseStatus(code=HttpStatus.BAD_REQUEST)
		public ErrorInfo handleException1(Exception ex) {
			return new ErrorInfo(ex.getMessage());
		}

}
