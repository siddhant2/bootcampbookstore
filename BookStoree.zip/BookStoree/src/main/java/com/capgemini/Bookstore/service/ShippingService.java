package com.capgemini.Bookstore.service;

import java.util.List;

import com.capgemini.Bookstore.entity.Shipping;

public interface ShippingService {

	public List<Shipping> showallshipping();
	
	public String updateShipping(Shipping shipping);
	
}
