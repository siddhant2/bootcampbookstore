package com.capgemini.Bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.Bookstore.entity.Shipping;

public interface ShippingDao extends JpaRepository<Shipping, Integer> {

}
