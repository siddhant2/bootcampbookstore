package com.capgemini.Bookstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bookstore {

	@Test
	void contextLoads() {
	}

}
