import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Shipping } from './shipping';

@Injectable({
  providedIn: 'root'
})
export class ShippingService {

  constructor(private http:HttpClient) { }

  public showallshipping():Observable<any>{
    console.log("Am inside service");
    return this.http.get("http://localhost:8555/viewallshipping");
  }

  updateShipping(shipping: Shipping): Observable<Object> {
    
    return this.http.put("http://localhost:8555/updateShipping",shipping,{responseType: 'text' });
  }
}