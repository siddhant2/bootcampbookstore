import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UpdateShippingComponent } from './updateShipping/updateShipping.component';
import { ShowallshippingComponent } from './showallshipping/showallshipping.component';
@NgModule({
  declarations: [
    AppComponent,
    UpdateShippingComponent,
    ShowallshippingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
