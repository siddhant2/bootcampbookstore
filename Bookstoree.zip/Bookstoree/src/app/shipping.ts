export class Shipping {
    shippingId:number;
    shippingName:string;
    shippingStreet1:string;
    shippingStreet2:string;
    shippingCity:string;
    shippingState:string;
    shippingCountry:string;
    shippingZipcode:number;
}
