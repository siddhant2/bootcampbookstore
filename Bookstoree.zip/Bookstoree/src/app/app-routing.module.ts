import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowallshippingComponent } from './showallshipping/showallshipping.component';
import { UpdateShippingComponent } from './updateShipping/updateShipping.component';
const routes: Routes = [
  {path:'showallshipping', component:ShowallshippingComponent},
  {path:'updateshipping', component:UpdateShippingComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
