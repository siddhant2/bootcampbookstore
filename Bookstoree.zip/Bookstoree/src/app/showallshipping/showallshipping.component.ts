import { Component, OnInit } from '@angular/core';
import { ShippingService } from '../shipping.service';
import { Shipping } from '../shipping';

@Component({
  selector: 'app-showallshipping',
  templateUrl: './showallshipping.component.html',
  styleUrls: ['./showallshipping.component.css']
})
export class ShowallshippingComponent implements OnInit {

  shippings:Shipping[]=[];

  constructor(private shippingService:ShippingService) { }

  ngOnInit(): void {
    console.log("Am inside show category");
    this.shippingService.showallshipping().subscribe(data=>this.shippings=data);
    console.log(this.shippings);
  }

}
