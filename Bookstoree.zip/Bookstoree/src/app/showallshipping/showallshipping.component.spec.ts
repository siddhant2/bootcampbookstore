import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowallshippingComponent } from './showallshipping.component';

describe('ShowallshippingComponent', () => {
  let component: ShowallshippingComponent;
  let fixture: ComponentFixture<ShowallshippingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowallshippingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowallshippingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
