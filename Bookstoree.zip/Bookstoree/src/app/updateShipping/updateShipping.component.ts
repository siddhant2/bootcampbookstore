import { Component, OnInit } from '@angular/core';
import { Shipping } from '../shipping';
import { ShippingService } from '../shipping.service';

@Component({
  selector: 'app-updateShipping',
  templateUrl: './updateShipping.component.html',
  styleUrls: ['./updateShipping.component.css']
})
export class UpdateShippingComponent implements OnInit {

  shipping: Shipping = new Shipping();
  msg: string;
  errormsg: string;
  
    constructor(private shippingservice: ShippingService) { }
  
    ngOnInit(): void {
    }
    updateShipping(){
      this.shippingservice.updateShipping(this.shipping).subscribe((data) => {
        console.log(data);
        //this.msg = data;
        this.errormsg = undefined;
        this.shipping= new Shipping(); },
        error => {this.errormsg = JSON.parse(error.error).msg;
                  console.log(error.error);
                  this.msg = undefined; });
      }
  
    }
